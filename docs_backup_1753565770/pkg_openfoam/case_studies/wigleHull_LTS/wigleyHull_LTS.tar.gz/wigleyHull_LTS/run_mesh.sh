#!/bin/bash

foamCleanTutorials
rm -rf 0 > /dev/null 2>&1
cp -r 0_org 0 > /dev/null 2>&1

fluentMeshToFoam ./mesh/ascii.cas
cp system/boundary ./constant/polyMesh/
cp system/fvSolution.1 system/fvSolution

