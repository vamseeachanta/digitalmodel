set grid xtics
set grid ytics
#set grid mxtics
#set grid mytics

#set key left
set ylabel "Water level - Height (m)"
set xlabel "Hull position - X coordinate (m)"

#plot '< sed "s/,/ /g" gnuplot/alpha.csv' u 2:4 w p pt 7 title "alpha", \
#     '< sed "s/,/ /g" gnuplot/alphamean.csv' u 2:4 w p pt 7 title "alphaMean", \
#     '../experimental_results/ship_hull_experimental_data.xy' u 1:2 w lp pt 7 title "Experiment"

set terminal qt 1

plot 'gnuplot/data_val.dat' u 3:1 w l title 'Numerical simulation', 'experimental_results/ship_hull_experimental_data.xy' u 1:2 pt 7 title "Experimental data"

set terminal qt 2

plot 'gnuplot/data1.dat' u 2:1 w l title 'Numerical simulation - Numerics 1', 'gnuplot/data2.dat' u 2:1 w l title 'Numerical simulation - Numerics 2', 'experimental_results/ship_hull_experimental_data.xy' u 1:2 pt 7 title "Experimental data"

pause -1
