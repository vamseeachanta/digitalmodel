#!/bin/bash

gnuplot gnuplot/gnuplot_script.sh
